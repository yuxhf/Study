
import java.io.*;

public class S7_2 {
    public static void main(String[] args) {
        long startTime, endTime;
        long byteStreamTime, bufferedStreamTime;

        // 使用字节流复制图片文件
        startTime = System.currentTimeMillis();
        try (FileInputStream fis = new FileInputStream("source.jpg");
             FileOutputStream fos = new FileOutputStream("target1.jpg")) {
            int byteRead;
            while ((byteRead = fis.read()) != -1) {
                fos.write(byteRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        endTime = System.currentTimeMillis();
        byteStreamTime = endTime - startTime;
        System.out.println("使用字节流复制图片文件耗时：" + byteStreamTime + "毫秒");

        // 使用字节缓冲流复制图片文件
        startTime = System.currentTimeMillis();
        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream("source.jpg"));
             BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("target2.jpg"))) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = bis.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        endTime = System.currentTimeMillis();
        bufferedStreamTime = endTime - startTime;
        System.out.println("使用字节缓冲流复制图片文件耗时：" + bufferedStreamTime + "毫秒");

        // 比较两种方法的运行时间
        if (byteStreamTime < bufferedStreamTime) {
            System.out.println("使用字节流复制图片文件更快！");
        } else if (byteStreamTime > bufferedStreamTime) {
            System.out.println("使用字节缓冲流复制图片文件更快！");
        } else {
            System.out.println("两种方式的复制时间相同！");
        }
    }
}