import java.io.*;
import java.util.Arrays;

public class S7_6 {
    public static void main(String[] args) {
        String desktopPath = "C:/Users/86198/Desktop/";
        String inputFile = desktopPath + "test.txt";
        String outputFile = desktopPath + "ss.txt";

        try {
            // 读取文件内容
            String content = readFile(inputFile);

            // 对数据进行排序
            String sortedContent = sortString(content);

            // 写入排序后的结果
            writeFile(outputFile, sortedContent);

            System.out.println("排序完成，结果已写入 ss.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 读取文件内容
    private static String readFile(String path) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }
        return sb.toString();
    }

    // 对字符串进行排序
    private static String sortString(String input) {
        char[] chars = input.toCharArray();
        Arrays.sort(chars);
        return new String(chars);
    }

    // 写入文件
    private static void writeFile(String path, String content) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            writer.write(content);
        }
    }
}