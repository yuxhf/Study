import java.io.*;
import java.util.*;

public class S7_4 {
    public static void main(String[] args) {
        String desktopPath = "C:/Users/86198/Desktop/";
        String fileName = "test.txt";
        String filePath = desktopPath + fileName;

        try (Scanner scanner = new Scanner(System.in);
             BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true));
             BufferedReader reader = new BufferedReader(new FileReader(filePath))) {

            // 向文件中写入键盘输入的内容
            System.out.print("请输入要写入文件的内容：");
            String input = scanner.nextLine();
            writer.write(input);
            writer.newLine();
            writer.flush();
            System.out.println("内容已成功写入文件 " + fileName);

            // 重新读取文件内容并显示到控制台
            System.out.println("重新从文件 " + fileName + " 读取内容并显示到控制台：");
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }

            System.out.println();

            // 键盘录入5个学生信息并按成绩追加存入文件
            System.out.println("请依次录入5个学生的信息（姓名 成绩）：");
            for (int i = 1; i <= 5; i++) {
                System.out.print("第 " + i + " 个学生的姓名：");
                String name = scanner.next();
                System.out.print("第 " + i + " 个学生的成绩：");
                int score = scanner.nextInt();
                writer.write(name + " " + score);
                writer.newLine();
                writer.flush();
            }
            System.out.println("学生信息已追加存入文件 " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}