import java.io.*;

public class S7_5 {
    public static void main(String[] args) {
        String desktopPath = "C:/Users/86198/Desktop/";
        String sourceFile = desktopPath + "test.txt";
        String targetFolder = desktopPath + "jvav/";

        try {
            copyFileToFolder(sourceFile, targetFolder);
            System.out.println("文件复制完成");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 复制文件到文件夹
    private static void copyFileToFolder(String sourceFile, String targetFolder) throws IOException {
        File folder = new File(targetFolder);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        String fileName = new File(sourceFile).getName();
        String targetFilePath = targetFolder + fileName;

        try (InputStream in = new FileInputStream(sourceFile);
             OutputStream out = new FileOutputStream(targetFilePath)) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
        }
    }
}