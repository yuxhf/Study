import java.io.File;

public class S7_1 {
    public static void main(String[] args) {
        File directory = new File("C:/Users/86198");
        File[] files = directory.listFiles();
        for (File file : files) {
            if (file.isFile() && file.getName().endsWith(".jpg")) {
                System.out.println(file.getName());
            }
        }
    }
}