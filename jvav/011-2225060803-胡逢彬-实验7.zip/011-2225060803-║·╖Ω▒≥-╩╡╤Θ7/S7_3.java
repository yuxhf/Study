import java.io.*;

public class S7_3 {
    public static void main(String[] args) {
        // 拷贝文本文件
        try {
            copyUsingInputStreamReaderAndOutputStreamWriter();
            copyUsingFileReaderAndFileWriter();
            copyUsingBufferedReaderAndBufferedWriter();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 使用InputStreamReader和OutputStreamWriter进行拷贝
    private static void copyUsingInputStreamReaderAndOutputStreamWriter() throws IOException {
        try (InputStreamReader isr = new InputStreamReader(new FileInputStream("C:/Users/86198/Desktop/test.txt"), "UTF-8");
             OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream("C:/Users/86198/Desktop/target1.txt"), "UTF-8")) {
            int c;
            while ((c = isr.read()) != -1) {
                osw.write(c);
            }
        }
        System.out.println("使用InputStreamReader和OutputStreamWriter进行拷贝完成");
    }

    // 使用FileReader和FileWriter进行拷贝
    private static void copyUsingFileReaderAndFileWriter() throws IOException {
        try (FileReader fr = new FileReader("C:/Users/86198/Desktop/test.txt");
             FileWriter fw = new FileWriter("C:/Users/86198/Desktop/target2.txt")) {
            int c;
            while ((c = fr.read()) != -1) {
                fw.write(c);
            }
        }
        System.out.println("使用FileReader和FileWriter进行拷贝完成");
    }

    // 使用BufferedReader和BufferedWriter进行拷贝
    private static void copyUsingBufferedReaderAndBufferedWriter() throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader("C:/Users/86198/Desktop/test.txt"));
             BufferedWriter bw = new BufferedWriter(new FileWriter("C:/Users/86198/Desktop/target3.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                bw.write(line);
                bw.newLine();
            }
        }
        System.out.println("使用BufferedReader和BufferedWriter进行拷贝完成");
    }
}