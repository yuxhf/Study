class Employee {
    private String name;
    private int age;
    private String employeeID;
    protected double salary;
    private int yearsOfService;
    public Employee(String name, int age, String employeeID, double salary, int yearsOfService) {
        this.name = name;
        this.age = age;
        this.employeeID = employeeID;
        this.salary = salary;
        this.yearsOfService = yearsOfService;
    }
    public void raiseSalary() {
        salary *= 1.1;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Employee ID: " + employeeID);
        System.out.println("Salary: " + salary);
        System.out.println("Years of Service: " + yearsOfService);
    }
}
class Manager extends Employee {
    public Manager(String name, int age, String employeeID, double salary, int yearsOfService) {
        super(name, age, employeeID, salary, yearsOfService);
    }
    public void raiseSalary() {
        salary *= 1.2;
    }
}
class SalaryTest {
    public static void main(String[] args) {
        Employee emp = new Employee("John Doe", 30, "E001", 50000,
                5);
        Manager manager = new Manager("Jane Smith", 40, "M001", 80000,
                8);
        emp.raiseSalary();
        manager.raiseSalary();
        System.out.println("Employee Information:");
        emp.displayInfo();
        System.out.println("\nManager Information:");
        manager.displayInfo();
    }
}
