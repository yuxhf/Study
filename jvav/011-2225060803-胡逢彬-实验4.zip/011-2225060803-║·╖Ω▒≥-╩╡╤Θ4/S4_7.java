class InsufficientIncomeException extends Exception {
    public InsufficientIncomeException(String message) {
        super(message);
    }
}
interface Employee {
    int getSalary();
}

class Student {
    private int monthlyFee;

    public Student(int monthlyFee) {
        this.monthlyFee = monthlyFee;
    }

    public int getMonthlyFee() {
        return monthlyFee;
    }
}
class OnTheJobPostgraduate extends Student implements Employee {
    private int salary;

    public OnTheJobPostgraduate(int salary, int monthlyFee) {
        super(monthlyFee);
        this.salary = salary;
    }

    @Override
    public int getSalary() {
        return salary;
    }

    public void checkIncome() throws InsufficientIncomeException {
        int totalIncome = getSalary() - getMonthlyFee();
        if (totalIncome < 0) {
            throw new InsufficientIncomeException("哎呀！您需要更加努力地工作以支付学费。");
        }
        System.out.println("祝贺！您有足够的收入来支付学费！");
        System.out.println("总收入: " + totalIncome);
    }
}

 class GraduateIncomeTest {
    public static void main(String[] args) {
        OnTheJobPostgraduate postgrad = new OnTheJobPostgraduate(2500, 1000); // 假设测试的固定工资

        try {
            postgrad.checkIncome();
        } catch (InsufficientIncomeException e) {
            System.out.println(e.getMessage());
        }
    }
}
