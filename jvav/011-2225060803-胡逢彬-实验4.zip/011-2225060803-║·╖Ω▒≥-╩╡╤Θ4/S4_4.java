abstract class Vehicle {
    protected int wheelNum;
    protected int seatNum;

    public Vehicle(int wheelNum, int seatNum) {
        this.wheelNum = wheelNum;
        this.seatNum = seatNum;
    }

    public abstract void display();
}

class Bus extends Vehicle {
    public Bus(int wheelNum, int seatNum) {
        super(wheelNum, seatNum);
    }
    public void display() {
        System.out.println("Bus - Wheels: " + wheelNum + ", Seats: " + seatNum);
    }
}

class Motorcycle extends Vehicle {
    public Motorcycle(int wheelNum, int seatNum) {
        super(wheelNum, seatNum);
    }
    public void display() {
        System.out.println("Motorcycle - Wheels: " + wheelNum + ", Seats: " + seatNum);
    }
}

class VehicleTest {
    public static void main(String[] args) {
        Vehicle vehicle1 = new Bus(6, 40);
        Vehicle vehicle2 = new Motorcycle(2, 2);

        vehicle1.display();
        vehicle2.display();
    }
}