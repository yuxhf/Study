import java.util.Random;

interface Employee {
    int getSalary();
}

class Student {
    private int monthlyFee = 2000;

    public int getMonthlyFee() {
        return monthlyFee;
    }
}
class OnTheJobPostgraduate extends Student implements Employee {
    private int salary;
    public OnTheJobPostgraduate(int salary) {
        this.salary = salary;
    }
    public int getSalary() {
        return salary;
    }
}

class GraduateIncomeTest {
    public static void main(String[] args) {
        Random random = new Random();
        int randomSalary = 1000 + random.nextInt(2001); // 1000到3000生成随机工资
        OnTheJobPostgraduate postgrad = new OnTheJobPostgraduate(randomSalary);

        int totalIncome = postgrad.getSalary() - postgrad.getMonthlyFee();

        if (totalIncome >= 0) {
            System.out.println("祝贺！您有足够的收入来支付学费");
            System.out.println("总收入: " + totalIncome);
        } else {
            System.out.println("撸起袖子加油干！");
            System.out.println("总收入: " + totalIncome);
        }
    }
}