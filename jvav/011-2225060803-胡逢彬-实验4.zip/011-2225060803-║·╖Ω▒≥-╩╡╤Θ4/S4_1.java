 class Animal {
    public void eat() {
        System.out.println("Animal is eating.");
    }
}
 class Cat extends Animal {
    public void eat() {
        super.eat();
        System.out.println("Cat is eating.");
    }
}
 class Test {
    public static void main(String[] args) {
        Animal animal = new Animal();
        animal.eat();

        Cat cat = new Cat();
        cat.eat();
    }
}