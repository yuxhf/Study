interface Inner{
    void introduce();
}
class Outer{
    static Inner method() {
        return new Inner() {
            public void introduce() {
                System.out.println("实现了Inner接口的匿名内部类！");
            }
        };
    }
}
class InnerClassTest{
    public static void main(String[] args){
        Outer.method().introduce ();
    }
}
