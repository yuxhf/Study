final class MyClass {
    private final int num = 347;

    public final void printNum() { // 使用final关键字修饰成员方法，表示该方法不可被子类重写
        System.out.println("Number: " + num);
    }
    public static void main(String[] args) {
        MyClass myClass = new MyClass();
        myClass.printNum();
    }
}

