import java.util.Scanner;

public class S2_5_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("请输入用户名（长度不小于3）：");
        String username = sc.nextLine();

        System.out.print("请输入密码（长度不小于6）：");
        String password1 = sc.nextLine();

        System.out.print("请再次输入密码：");
        String password2 = sc.nextLine();

        if (username.length() < 3 || password1.length() < 6) {
            System.out.println("用户名或密码长度不符合要求！");
        } else if (!password1.equals(password2)) {
            System.out.println("两次输入的密码不相同！");
        } else {
            System.out.println("注册成功！");
        }
    }
}