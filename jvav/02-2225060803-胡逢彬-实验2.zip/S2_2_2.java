import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class S2_2_2 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int year = sc.nextInt();
        int month = sc.nextInt();

        YearMonth yearMonth = YearMonth.of(year, month);
        int daysInMonth = (int) yearMonth.lengthOfMonth();

        System.out.println(year + "年" + month + "月的天数是：" + daysInMonth + "天");
    }

}