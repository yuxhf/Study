import java.util.Scanner;

public class S2_2_1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        while(true)
        {
            int month=sc.nextInt();

            if(month<=5 && month>=3)
            {
                System.out.println("春天");
            }
            else if(month<=8 && month>=6)
            {
                System.out.println("夏天");
            }
            else if(month<=11 && month>=9)
            {
                System.out.println("秋天");
            }
            else
            {
                System.out.println("冬天");
            }
        }
    }

}