import java.util.Scanner;

public class S2_5_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("请输入学生的个数：");
        int count = sc.nextInt();

        String highestName = "";
        int highestScore = Integer.MIN_VALUE;
        String secondHighestName = "";
        int secondHighestScore = Integer.MIN_VALUE;

        for (int i = 1; i <= count; i++) {
            System.out.print("请输入第" + i + "个学生的名字：");
            String name = sc.next();

            System.out.print("请输入第" + i + "个学生的分数：");
            int score = sc.nextInt();

            if (score > highestScore) {
                secondHighestScore = highestScore;
                secondHighestName = highestName;
                highestScore = score;
                highestName = name;
            } else if (score > secondHighestScore) {
                secondHighestScore = score;
                secondHighestName = name;
            }
        }

        System.out.println("获得最高分的学生是：" + highestName + "，分数为：" + highestScore);
        System.out.println("第二高分的学生是：" + secondHighestName + "，分数为：" + secondHighestScore);
    }
}