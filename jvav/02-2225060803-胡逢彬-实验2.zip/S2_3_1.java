import java.util.Scanner;

public class S2_3_1 {
    public static void main(String[] args){
        int cnt = 1;
        double sum = 0;
        int flag = 1;
        double bit = 1;
        do {
            bit *= cnt;
            double tmp = 1.0 / bit;
            sum += flag * tmp;

            flag = -flag;
            cnt++;
        } while (cnt <= 20);
        sum=2-sum;
        System.out.println("前20项之和：" + sum);
    }

}