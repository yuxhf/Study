import java.util.Scanner;

public class S2_1_1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int []arr = new int[10];
        for(int i=0;i<10;i++)
        {
            arr[i]=sc.nextInt();
        }
        int sum=0;
        for(int i=0;i<10;i++)
        {
            System.out.println(arr[i]);
            sum+=arr[i];
        }

        System.out.println("sum = "+sum);
    }

}