import java.util.Scanner;
public class S2_5_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double s = sc.nextDouble();
        double area = 0;
        double pi = Math.PI;
        area = 6 * (s * s) / (4 * Math.tan(pi / 6.0));
        System.out.println(area);
    }
}