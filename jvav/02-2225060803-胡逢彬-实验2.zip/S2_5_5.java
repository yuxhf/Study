import java.util.Scanner;

public class S2_5_5 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int[][] a = new int[10][10];
        int[][] b = new int[10][10];

        int n=sc.nextInt();
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                a[i][j]=sc.nextInt();
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                b[j][i] = a[i][j];
            }
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(b[i][j] + " ");
            }
            System.out.println();
        }
    }
}