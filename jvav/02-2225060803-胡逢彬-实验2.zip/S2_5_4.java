import java.util.Scanner;

public class S2_5_4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int []a={2,3,4,1,3,12};
        int num=sc.nextInt();
        int flag=0;
        for(int i=0;i<a.length;i++)
        {
            if(num==a[i])flag=1;
        }
        if(flag==1)
        {
            System.out.println("存在");
        }
        else {
            System.out.println("不存在");
        }
    }
}