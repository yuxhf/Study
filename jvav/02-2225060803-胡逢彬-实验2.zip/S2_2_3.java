import java.time.YearMonth;
import java.util.Scanner;

public class S2_2_3 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.print("请输入公里数：");

        int dis=sc.nextInt();
        double val=0;
        if (dis <= 2) {
            val = 5;
        } else if (dis <= 9) {
            val = 5 + (dis - 2) * 1.3;
        } else {
            val = 5 + 7 * 1.3 + (dis - 9) * 2;
        }
        val++;
        System.out.println(val);
    }

}