public class Main {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(567);

        Thread studentWithdraw = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 3; i++) {
                    account.withdraw(500);
                }
            }
        });

        Thread parentDeposit = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 3; i++) {
                    account.deposit(2000);
                }
            }
        });

        studentWithdraw.start();
        parentDeposit.start();
    }
}

class BankAccount {
    private int balance;

    public BankAccount(int balance) {
        this.balance = balance;
    }

    public synchronized void withdraw(int amount) {
        while (balance < amount) {
            try {
                System.out.println("取款线程：余额不足，等待存款...");
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        balance -= amount;
        System.out.println("取款线程：成功取款 " + amount + " 元，当前余额为 " + balance + " 元");
        notify();
    }

    public synchronized void deposit(int amount) {
        balance += amount;
        System.out.println("存款线程：成功存款 " + amount + " 元，当前余额为 " + balance + " 元");
        notify();
    }
}