import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Digital Clock");
                frame.setLayout(new FlowLayout());
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                JLabel timeLabel = new JLabel(getCurrentTime());
                timeLabel.setFont(new Font("Arial", Font.PLAIN, 36));
                frame.add(timeLabel);

                frame.setSize(300, 100);
                frame.setVisible(true);

                Timer timer = new Timer();
                timer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        timeLabel.setText(getCurrentTime());
                    }
                }, 0, 1000);
            }
        });
    }

    private static String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.format(new Date());
    }
}