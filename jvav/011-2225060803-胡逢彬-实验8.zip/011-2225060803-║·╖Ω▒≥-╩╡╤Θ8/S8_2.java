public class User {
    public static void main(String[] args) {
        final int distance = 35;
        final int rabbitSpeed = 5;
        final int rabbitRestInterval = 10;
        final int rabbitRestTime = 2;
        final int turtleSpeed = 3;

        Thread rabbit = new Thread(new Runnable() {
            @Override
            public void run() {
                int position = 0;
                int restCount = 0;
                while (position < distance) {
                    position += rabbitSpeed;
                    System.out.println("兔子跑了 " + position + " 米");
                    if (++restCount == rabbitRestInterval) {
                        try {
                            System.out.println("兔子休息中...");
                            Thread.sleep(rabbitRestTime * 1000);
                            restCount = 0;
                            System.out.println("兔子休息结束，继续跑！");
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        Thread.sleep(100); // 模拟0.1秒时间流逝
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("兔子到达终点！");
            }
        });

        Thread turtle = new Thread(new Runnable() {
            @Override
            public void run() {
                int position = 0;
                while (position < distance) {
                    position += turtleSpeed;
                    System.out.println("乌龟跑了 " + position + " 米");
                    try {
                        Thread.sleep(100); // 模拟0.1秒时间流逝
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("乌龟到达终点！");
            }
        });

        rabbit.start();
        turtle.start();
    }
}