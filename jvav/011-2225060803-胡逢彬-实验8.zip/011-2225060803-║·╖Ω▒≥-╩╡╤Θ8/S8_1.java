import java.util.concurrent.atomic.AtomicInteger;

class TicketSeller implements Runnable {
    private static final AtomicInteger ticketNumber = new AtomicInteger(1);
    private static final int TOTAL_TICKETS = 100;
    private int windowNum;

    public TicketSeller(int windowNum) {
        this.windowNum = windowNum;
    }

    @Override
    public void run() {
        while (ticketNumber.get() <= TOTAL_TICKETS) {
            int currentTicket = ticketNumber.getAndIncrement();
            System.out.println("窗口" + windowNum + "售出第" + currentTicket + "张票");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Thread[] threads = new Thread[4];
        for (int i = 0; i < 4; i++) {
            threads[i] = new Thread(new TicketSeller(i + 1));
            threads[i].start();
        }

        for (int i = 0; i < 4; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}