import java.util.Scanner;

public class S3_4 {
    public  static  void main(String[] args){
        int i;
        fractions fractions=new fractions();
        Scanner in=new Scanner(System.in);
        int fson1=0;
        int fson2=0;
        int fmom1=0;
        int fmom2=0;
        System.out.println("请输入第一个分数的分子：");
        fson1=in.nextInt();
        System.out.println("请输入第一个分数的分母：");
        fmom1=in.nextInt();
        System.out.println("请输入第二个分数的分子：");
        fson2=in.nextInt();
        System.out.println("请输入第二个分数的分母：");
        fmom2=in.nextInt();
        System.out.println("1.开始运算");
        System.out.println("0.退出");
        System.out.println("请输入选择:");
        i=in.nextInt();
        if(i==0){
            System.out.println("已退出");
        }
        else {
            while (i!=0) {
                System.out.println("0.退出");
                System.out.println("1.加法");
                System.out.println("2.减法");
                System.out.println("3.乘法");
                System.out.println("4.除法");
                System.out.println("请输入选择：");
                i = in.nextInt();
                switch (i) {

                    case 1:
                        fractions.fAdd(fson1, fmom1, fson2, fmom2);
                        break;
                    case 2:
                        fractions.fSub(fson1, fmom1, fson2, fmom2);
                        break;
                    case 3:
                        fractions.fMul(fson1, fmom1, fson2, fmom2);
                        break;
                    case 4:
                        fractions.fDiv(fson1, fmom1, fson2, fmom2);
                        break;

                }
            }
        }

    }
}

