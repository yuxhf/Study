public class fractions {
    public int fson;
    public int fmom;
    public int gcd(int a,int b) {
        if (a < b) {
            int c = a;
            a = b;
            b = c;
        }
        int r = a % b;
        while (r != 0) {
            a = b;
            b = r;
            r = a % b;
        }

        return b;

    }
    public void fAdd(int fson1,int fmom1,int fson2,int fmom2){
        int fm=fmom1*fmom2;
        fson1=fson1*fmom2;
        fson2=fson2*fmom1;
        int fs=fson1+fson2;
        if( fs==0){
            System.out.println("结果为0");
        }
        else {

            int g = gcd(fs, fm);
            System.out.println("最大公约数：" + g);
            fs = fs / g;
            fm = fm / g;
            System.out.println("加法运算后结果中分子为：" + fs);
            System.out.println("加法运算后结果中分母为：" + fm);
            System.out.println("即分数为：" + fs + "/" + fm);
        }

    }
    public void fSub(int fson1,int fmom1,int fson2,int fmom2){
        int fm=fmom1*fmom2;
        fson1=fson1*fmom2;
        fson2=fson2*fmom1;
        int fs=fson1-fson2;
        if( fs==0){
            System.out.println("结果为0");
        }
        else {

            int g = gcd(fs, fm);
            fs = fs / g;
            fm = fm / g;
            System.out.println("减法运算后结果中分子为：" + fs);
            System.out.println("减法运算后结果中分母为：" + fm);
            System.out.println("即分数为：" + fs + "/" + fm);
        }


    }
    public void fMul(int fson1,int fmom1,int fson2,int fmom2){
        int fm=fmom1*fmom2;
        int fs=fson1*fson2;
        if( fs==0){
            System.out.println("结果为0");
        }
        else {

            int g = gcd(fs, fm);
            fs = fs / g;
            fm = fm / g;
            System.out.println("乘法运算后结果中分子为：" + fs);
            System.out.println("乘法运算后结果中分母为：" + fm);
            System.out.println("即分数为：" + fs + "/" + fm);
        }

    }
    public void fDiv(int fson1,int fmom1,int fson2,int fmom2){
        int fm=fmom1*fson2;
        int fs=fson1+fmom2;
        if( fs==0){
            System.out.println("结果为0");
        }
        else {

            int g = gcd(fs, fm);
            fs = fs / g;
            fm = fm / g;
            System.out.println("除法运算后结果中分子为：" + fs);
            System.out.println("除法运算后结果中分母为：" + fm);
            System.out.println("即分数为：" + fs + "/" + fm);
        }

    }

}

