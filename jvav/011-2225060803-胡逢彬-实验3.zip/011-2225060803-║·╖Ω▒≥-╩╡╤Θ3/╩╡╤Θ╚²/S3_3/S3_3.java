public class S3_3 {
    public static void main(String[] args)
    {
        date d=new date(2023,10,30);
        System.out.println(d.toString());

}
