public class S3_2 {
    public static void main(String[] args)
    {
        calculator c=new calculator();
        System.out.println(c.add(1,3));
        System.out.println(c.add(1.3,4.2));
        System.out.println("===========");
        System.out.println(c.sub(1,3));
        System.out.println(c.sub(1.3,4.2));
        System.out.println("===========");
        System.out.println(c.x(1,3));
        System.out.println(c.x(1.3,4.2));
        System.out.println("===========");
        System.out.println(c.ch(1,3));
        System.out.println(c.ch(1.3,4.2));
    }


}
