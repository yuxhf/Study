public class calculator {
    public int add(int a,int b)
    {
        return a+b;
    }
    public double add(double c,double d)
    {
        return c+d;
    }
    public int sub(int a,int b)
    {
        return a-b;
    }
    public double sub(double c,double d)
    {
        return c-d;
    }
    public int x(int a,int b)
    {
        return a*b;
    }
    public double x(double c,double d)
    {
        return c*d;
    }
    public int ch(int a,int b)
    {
        return (int)a/b;
    }
    public double ch(double c,double d)
    {
        return c/d;
    }




}
