public class S3_6 {
    public static void main(String[] agrs)
    {
        tv tv1 = new tv();
        tv1.showStatus();
        tv1.decreaseVolume(11);
        tv1.turnOn();
        tv1.changeChannel(23);
        tv1.increaseVolume(22);
        tv1.decreaseVolume(13);
        tv1.showStatus();
        tv1.turnOff();
    }
}
