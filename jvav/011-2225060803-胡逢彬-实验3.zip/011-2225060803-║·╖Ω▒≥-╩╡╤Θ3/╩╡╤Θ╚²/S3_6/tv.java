class tv {
    private static int idCounter = 1000; // 生成商品编号
    private  int productId; // 商品编号
    private boolean powerStatus; // 电视机开关状态
    private int volume; // 音量
    private int channel; // 频道

    public tv() {
        this.productId = idCounter++; // 自动生成商品编号
        this.powerStatus = false; // 初始状态为关闭
        this.volume = 10; // 初始音量为10
        this.channel = 1; // 初始频道为1
    }
    public tv(int idCounter, int productId, boolean powerStatus, int volume, int channel) {
        this.idCounter = idCounter;
        this.productId = productId;
        this.powerStatus = powerStatus;
        this.volume = volume;
        this.channel = channel;
    }

    // 静态方法，获取当前商品编号计数
    public static int getCurrentIdCounter() {
        return idCounter;
    }

    public static int getIdCounter() {
        return idCounter;
    }

    public static void setIdCounter(int idCounter) {
        tv.idCounter = idCounter;
    }

    public void turnOn() {
        powerStatus = true;
        System.out.println("电视机已开启。");
    }

    public void turnOff() {
        powerStatus = false;
        System.out.println("电视机已关闭。");
    }

    public void changeChannel(int newChannel) {
        if (powerStatus) {
            this.channel = newChannel;
            System.out.println("频道已更换到：" + newChannel);
        } else {
            System.out.println("电视机未开启，无法更换频道。");
        }
    }

    public void increaseVolume(int increment) {
        if (powerStatus) {
            this.volume += increment;
            System.out.println("音量已增加，当前音量：" + volume);
        } else {
            System.out.println("电视机未开启，无法调整音量。");
        }
    }


    public void decreaseVolume(int decrement) {
        if (powerStatus) {
            this.volume = Math.max(0, this.volume - decrement);
            System.out.println("音量已减小，当前音量：" + volume);
        } else {
            System.out.println("电视机未开启，无法调整音量。");
        }
    }

    public void showStatus() {
        System.out.println("商品编号：" + productId);
        System.out.println("开关状态：" + (powerStatus ? "开启" : "关闭"));
        System.out.println("当前音量：" + volume);
        System.out.println("当前频道：" + channel);
    }

    public boolean isPowerStatus() {
        return powerStatus;
    }

    public void setPowerStatus(boolean powerStatus) {
        this.powerStatus = powerStatus;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public int getChannel() {
        return channel;
    }

    public void setChannel(int channel) {
        this.channel = channel;
    }

    public String toString() {
        return "tv{idCounter = " + idCounter + ", productId = " + productId + ", powerStatus = " + powerStatus + ", volume = " + volume + ", channel = " + channel + "}";
    }
}