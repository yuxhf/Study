import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class S3_8 {

    public static void main(String[] args)
    {
        ATM ATM1=new ATM();
        ATM1.start();
    }

}
