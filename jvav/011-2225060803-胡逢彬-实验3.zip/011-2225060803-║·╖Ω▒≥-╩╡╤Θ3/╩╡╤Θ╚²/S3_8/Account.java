import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Account {
    private String cardId; //卡号
    private String userName; //用户名
    private char sex; //性别
    private String passWord;//密码
    private double money; //余额
    private double limit; // 限额

    public Account() {}
    public Account(String cardId, String userName, char sex, String passWord, double money, double limit) {
        this.cardId = cardId;
        this.userName = userName;
        this.sex = sex;
        this.passWord = passWord;
        this.money = money;
        this.limit = limit;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getUserName() {
        return userName + ( sex  == '男' ? "先生" : "女士");
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public double getLimit() {
        return limit;
    }

    public void setLimit(double limit) {
        this.limit = limit;
    }

    public String toString() {
        return "Account{cardId = " + cardId + ", userName = " + userName + ", sex = " + sex + ", passWord = " + passWord + ", money = " + money + ", limit = " + limit + "}";
    }
    public String getCardId(String cardId){
        return cardId;
    }

}