public class clerk {
    private int id;             // 编号
    private String name;       // 姓名
    private int age;           // 年龄
    private String position;   // 职务
    private String department; // 部门
    private boolean iscome;
    // 出勤人数
    private static int attendanceCount = 0;
    public clerk(int id, String name, int age, String position, String department,boolean iscome) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.position = position;
        this.department = department;
        this.iscome=iscome;
//        this.attendanceCount = attendanceCount;
    }

    public static void setAttendanceCount(int attendanceCount) {
        clerk.attendanceCount = attendanceCount;
    }

    // 初始化雇员信息

    public void displayInfo() {
        System.out.println("编号: " + id);
        System.out.println("姓名: " + name);
        System.out.println("年龄: " + age);
        System.out.println("职务: " + position);
        System.out.println("部门: " + department);
    }

    // 签到
    public void signIn() {
        if(iscome==true) {
            attendanceCount++; // 出勤人数加1
            System.out.println(name + " 已签到！");
        }
        else
        {
            System.out.println(name+"离职警告！！！");
        }
    }
    // 获取当前出勤人数
    public static int getAttendanceCount() {
        return attendanceCount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String toString() {
        return "clerk{id = " + id + ", name = " + name + ", age = " + age + ", position = " + position + ", department = " + department + ", attendanceCount = " + attendanceCount + "}";
    }
}
