public class S3_5 {


    public static void main(String[] args) {
        // 创建两个雇员对象
        clerk c1 = new clerk(1, "张三", 20, "工程师", "技术部门",true);
        clerk c2 = new clerk(2, "李四", 19, "端水", "技术部门",true);
        clerk c3 = new clerk(3,"王五",32,"打杂","技术部门",false);
        // 输出雇员信息
        c1.displayInfo();
        System.out.println();
        System.out.println("==========");
        System.out.println();
        // 雇员签到
        c1.signIn();
        c2.signIn();
        c3.signIn();

        // 统计并输出出勤人数
        System.out.println("当前出勤人数: " + c3.getAttendanceCount());
    }
}
