public class S3_1 {
    public static void main(String[] args) {
//        System.out.println("Hello world!");
        Student s1=new Student("123","张三","male",12);
        Student s2=new Student("456","李四","female",18);
        System.out.println(s1.showNo());
        System.out.println(s1.showName());
        System.out.println(s1.showSex());
        System.out.println(s1.showAge());
        System.out.println();
        System.out.println("=================");
        System.out.println();
        System.out.println(s2.showNo());
        System.out.println(s2.showName());
        System.out.println(s2.showSex());
        System.out.println(s2.showAge());
        System.out.println();
        System.out.println("=================");
        System.out.println();
        s1.modifyAge(88);
        System.out.println(s1.showAge());
    }
}