public class Student {
    private String studentNo;
    private String studentName;
    private String studentGender;
    private int    studentAge;

    public Student() {}

    public Student(String studentNo, String studentName, String studentGender, int studentAge) {
        this.studentNo = studentNo;
        this.studentName = studentName;
        this.studentGender = studentGender;
        this.studentAge = studentAge;
    }

    public String showNo() {
        return studentNo;
    }

    public void setStudentNo(String studentNo) {
        this.studentNo = studentNo;
    }

    public String showName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String showSex() {
        return studentGender;
    }

    public void setStudentGender(String studentGender) {
        this.studentGender = studentGender;
    }

    public int showAge() {
        return studentAge;
    }


    public void modifyAge(int studentAge) {
        this.studentAge = studentAge;
    }

    public String toString() {
        return "Student{studentNo = " + studentNo + ", studentName = " + studentName + ", studentGender = " + studentGender + ", studentAge = " + studentAge + "}";
    }
}
