package xz.tankwar.component;

public interface Automatic {
    void autoAct();
    boolean isAlive();
}
