#include <iostream>
#include <string>
const int N=300;
int a[N];
int main()
{
	std::string s;
	getline(std::cin,s);
	for(int i=0;i<s.size();i++)
	{
		a[(int)s[i]]++;
	}
	for(int i=0;i<=140;i++)
	{
		if(a[i])
		{
			std::cout<<char(i)<<" "<<a[i]<<"\n";
		}
	}
	return 0;
}