#include <bits/stdc++.h>
using namespace std;
const int N=1e6+10;
int vis[N];
int prime[N];
int cnt=0;
void Eprime(int k)
{
    for(int i=2;i<=k;i++)
    {
        if(!vis[i])
        {
            prime[cnt]=i;
            vis[i]=1;
            cnt++;
        }
        for(int j=0;j<cnt;j++)
        {
            if(prime[j]*i>k)break;
            vis[prime[j]*i]=1;
            if(i%prime[j]==0)break;
        }
    }
}
int main()
{
    Eprime(200);
    for(int i=0;i<cnt;i++)
    {
        cout<<prime[i]<<" ";
        if(i%5==4)cout<<endl;
    }
    return 0;
}
